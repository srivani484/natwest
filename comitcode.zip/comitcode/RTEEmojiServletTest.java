package com.responsive.cer.servlet;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.security.Key;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.servlet.ServletOutputStream;

import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.servlethelpers.MockSlingHttpServletRequest;
import org.apache.sling.servlethelpers.MockSlingHttpServletResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.adobe.granite.keystore.KeyStoreService;
import com.responsive.btcalculator.dto.BTCalculatorDTO;
import com.responsive.btcalculator.servlet.BTCalculatorServlet;
import com.responsive.cer.models.RTEEmojiConfigBean;
import com.responsive.cer.models.RTEEmojiConfigModel;
import com.responsive.eucalc.servlet.EUCalcHealthCheckServlet;
import com.responsive.fhc.servlet.FHCReportServlet.Configuration;
import com.responsive.tool.util.ToolsUtility;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

/**
 * Test Class for Java class {@link com.responsive.ifwptool.models.InvestmentFundsChildModel
 */

@RunWith(PowerMockRunner.class)

public class RTEEmojiServletTest {

	@InjectMocks
    public RTEEmojiServlet rteEmojiServlet=new RTEEmojiServlet();

	
	@Mock
	private MockSlingHttpServletRequest request;

	@Mock
	private MockSlingHttpServletResponse response;
	@Mock
	ResourceResolver resourceResolver;
	@Mock
	private RTEEmojiConfigModel rteEmojiConfigModel;
	
    
    @Before
	public void setup() throws Exception {
    	  
    	  MockitoAnnotations.initMocks(this);    	
          Resource mockedResource = mock(Resource.class);
      	
        when(request.getResourceResolver()).thenReturn(resourceResolver);
    	when(resourceResolver.getResource("/content/globalconfig/jcr:content/master-par/emojiconfig")).thenReturn(mockedResource);
    	PrintWriter printwriter = Mockito.mock(PrintWriter.class);
		Mockito.doNothing().when(printwriter).write(Mockito.anyString());
		Mockito.when(response.getWriter()).thenReturn(printwriter);
    	when(mockedResource.adaptTo(RTEEmojiConfigModel.class)).thenReturn(rteEmojiConfigModel);
         
        
      
    }

    /**
     * Test case for method {@link com.responsive.fhc.servlet.FHCReportServlet#activate
     */
    @Test
    public void testGet() {
    	
		when(request.getParameter("search")).thenReturn("face");
		List<RTEEmojiConfigBean> list = new ArrayList<>();
    	list.add(new RTEEmojiConfigBean());
when(rteEmojiConfigModel.getEmojiConfigs()).thenReturn(list);
    	rteEmojiServlet.doGet(request, response);
    	 assertEquals("application/json;charset=UTF-8", response.getContentType());
    	
    }
    
    /**
     * Test case for method {@link com.responsive.fhc.servlet.FHCReportServlet#activate
     */
    @Test
    public void testGetQuery() {
    	
		when(request.getParameter("search")).thenReturn("facesmiley");

    	rteEmojiServlet.doGet(request, response);
    	
    }
}
   