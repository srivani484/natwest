package com.responsive.cer.models;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith(AemContextExtension.class)
public class RTEEmojiConfigModelTest {

    @InjectMocks
    RTEEmojiConfigModel model = new RTEEmojiConfigModel();

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetEmojiConfigs() {
        List<RTEEmojiConfigBean> mockEmojiConfigs = new ArrayList<>();
        RTEEmojiConfigBean emojiConfigBean = new RTEEmojiConfigBean();
        emojiConfigBean.emojiName = "Smile";
        emojiConfigBean.emojiValue = ":)";
        mockEmojiConfigs.add(emojiConfigBean);
        model.emojiConfigs = mockEmojiConfigs;
        List<RTEEmojiConfigBean> emojiConfigs = model.getEmojiConfigs();

        assertEquals(1, emojiConfigs.size());
        assertEquals(emojiConfigs.get(0).getEmojiName(),"Smile");
        assertEquals(emojiConfigs.get(0).getEmojiValue(),":)");
    }

    @Test
    public void testGetEmojiConfigsEmpty() {
        model.emojiConfigs=null;
        List<RTEEmojiConfigBean> emojiConfigs = model.getEmojiConfigs();
        assertEquals(Collections.emptyList(), emojiConfigs);
    }
}