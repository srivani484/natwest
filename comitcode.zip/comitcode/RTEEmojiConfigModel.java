package com.responsive.cer.models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Sling model for the RTE Emoji Configuration component. Path of
 * component:responsive/components/configs/emojiconfig
 *
 * @author muppas
 *
 */
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL, resourceType = "responsive/components/configs/emojiconfig")
public class RTEEmojiConfigModel {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(RTEEmojiConfigModelTest.class);

	/** The {@link List} of configs authored. */
	@ChildResource
	 List<RTEEmojiConfigBean> emojiConfigs;

	/**
	 * Gets the list of the Emoji variables authored. Each item in the list has the
	 * Emoji name and value to get display in content fragment RTE plugin
	 *
	 * @return { List} of type {RTEEmojiConfigBean}
	 */
	public List<RTEEmojiConfigBean> getEmojiConfigs() {
		if (emojiConfigs != null) {

			return new ArrayList<>(emojiConfigs);
		}
		return Collections.emptyList();
	}
}
