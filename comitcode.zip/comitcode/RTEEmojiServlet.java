package com.responsive.cer.servlet;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.Servlet;
import javax.servlet.http.HttpServletResponse;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.ServletResolverConstants;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.responsive.cer.models.RTEEmojiConfigBean;
import com.responsive.cer.models.RTEEmojiConfigModel;

/**
 * This servlet is used for bt calculations to written json details information
 * 
 *
 */

@Component(service = Servlet.class, property = { "label" + "= RTE Emoji Servlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_GET,
		ServletResolverConstants.SLING_SERVLET_PATHS + "=" + "/services/tool/cer/rteemoji",
		ServletResolverConstants.SLING_SERVLET_EXTENSIONS + "=" + "json" })
public class RTEEmojiServlet extends SlingSafeMethodsServlet {

	/**
	 * Generated UUID
	 */
	private static final long serialVersionUID = 4194704871898905023L;

	private RTEEmojiConfigModel rteEmojiConfigModel;
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(RTEEmojiServlet.class);

	private static final String EMOJI_CONFIG_PATH = "/content/globalconfig/jcr:content/master-par/emojiconfig";
	private static final String SEARCH_PARAM = "search";
	private static final String FACE_VALUE = "face";

	/**
	 * DoGet Method.
	 */
	@Override
	public void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) {
		try {
			List<RTEEmojiConfigBean> results = Collections.emptyList();
			ResourceResolver resolver = request.getResourceResolver();
			String searchParam = request.getParameter(SEARCH_PARAM);
			Resource resource = resolver.getResource(EMOJI_CONFIG_PATH);
			rteEmojiConfigModel = resource.adaptTo(RTEEmojiConfigModel.class);
			response.setContentType("application/json");
			response.setStatus(HttpServletResponse.SC_OK);
			if (searchParam.equalsIgnoreCase(FACE_VALUE)) {
				results = rteEmojiConfigModel.getEmojiConfigs();
			} else {

				results = rteEmojiConfigModel.getEmojiConfigs().stream()
						.filter(p -> p.getEmojiName().equalsIgnoreCase(searchParam)).collect(Collectors.toList());
			}

			response.getWriter().println(new Gson().toJson(results));

		} catch (IOException e) {
			LOGGER.error("Error while writing the response object.", e);
		}
	}

}
